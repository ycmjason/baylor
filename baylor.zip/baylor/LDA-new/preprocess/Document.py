import nltk
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer

import re

from stoplists import MySqlStoplist


class Document:
    def __init__(self, doc_str):
        self.doc_str = doc_str.decode('utf-8', 'ignore').lower()
        self.pos_tags = self._pos_tags()
    def _pos_tags(self):
        return nltk.pos_tag(nltk.word_tokenize(self.doc_str))
    def getTokens(self):
        return map(lambda tag: tag[0], self.pos_tags)
    def filterTokens(self, fn):
        self.pos_tags = filter(lambda tag: fn(tag[0]), self.pos_tags)
        return self
    def mapTokens(self, fn):
        self.pos_tags = map(lambda tag: fn(tag[0]), self.pos_tags)
        return self
    def removePunctuation(self):
        pattern = r"(^[a-z]+(-?[a-z0-9]+)*$)|(^([a-z]\.)+$)"
        self.filterTokens(lambda token: re.search(pattern, token))
        return self
    def removeStopwords(self):
        # initialize MySqlStoplist
        stoplist = MySqlStoplist()

        # get rid of all stopwords
        self.filterTokens(lambda token: not stoplist.isStopword(token))
        return self
    def stem(self):
        # 'pos' means 'part of speech'
        def isLemmatizable(pos):
            return pos_nltk2wn(pos) is not None

        def pos_nltk2wn(nltk_pos):
            lookup_table = {}
            lookup_table['N'] = 'n'
            lookup_table['V'] = 'v'
            lookup_table['J'] = 'a'
            lookup_table['R'] = 'r'

            if nltk_pos[0] in lookup_table:
                return lookup_table[nltk_pos[0]]
            else:
                return None

        # initialize stemmer and lemmatizer
        stemmer = SnowballStemmer("english")
        lemmatizer = WordNetLemmatizer()
        
        # lemmatize/stem words
        for i, (word, pos) in enumerate(self.pos_tags):
            if isLemmatizable(pos):
                word = lemmatizer.lemmatize(word, pos=pos_nltk2wn(pos))
            else:
                word = stemmer.stem(word)
            self.pos_tags[i] = (word, pos)

        return self
