"""
This package contains classes to compare similarities between topics or topic lists
"""