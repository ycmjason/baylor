from similarity.BCDistance import BCDistance
from similarity.KLDivergence import KLDivergence
from similarity.CosDistance import CosDistance

from topic.topicio import TopicIO
from similarity.SimTopicLists import SimTopicLists
import sys
import utils.name_convention as name

topics_io = TopicIO()
stl = SimTopicLists()

if len(sys.argv) <= 1:
    corpus_type = "bow"
else:
    if sys.argv[1] == "t":
        corpus_type = "tfidf"
    elif sys.argv[1] == "b":
        corpus_type = "binary"
    else:
        corpus_type = "bow"

if len(sys.argv) <= 2:
    max_topics_count = 3
else:
    max_topics_count = int(sys.argv[2])

if len(sys.argv) <= 3:
    src = "pp_test"
else:
    src = sys.argv[3]

# Here assumes that LDA_...._t1..max_topics_count has been processed

topics_dirs = [name.get_output_dir(corpus_type, i, src) + '/topics' for i in range(1, max_topics_count + 1)]
t_lists = [topics_io.read_topics(topics_dir) for topics_dir in topics_dirs]

#for t_list in t_lists:
#    for topic in t_list:
#        topic.sort()
#
#for i, t_list in enumerate(t_lists):
#    print "======> Topic count: " + str(i+1)
#    for j, topic in enumerate(t_list):
#        print "Topic " + str(j + 1) + ": " + str(topic.list(5))
#        topic.sortByWord()
#    print '\n'

print '========= calculating similarity ============='

bha = BCDistance()
kl = KLDivergence()
cs = CosDistance()

distances = [method.distance for method in [bha, kl, cs]]

#print [map(lambda topic: topic.size(), t_list) for t_list in t_lists]

for i in range(0, max_topics_count-1):
    print "======> Topic count: " + str(i + 1)
    for j, topic in enumerate(t_lists[i]):
        print "Comparing Topic #" + str(j + 1) + " with the successive topics"
        for distance in distances:
            print distance.im_class.__name__ + ': ' + str([distance(topic, topic_succ) for topic_succ in t_lists[i+1]])
        print
    print
