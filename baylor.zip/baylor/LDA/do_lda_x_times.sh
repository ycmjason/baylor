usage ()
{
  echo "Usage: sh do_lda_x_times.sh <src of corpus> <x times>"
}

showArgs ()
{
  echo "Corpus directory: $1"
  echo "Do lda $2 times with topic counts from 1 to $2"
}

shout ()
{
  echo "===========> $1"
}

if ! [[ -r $1 ]]; then
  echo "Bad src."
  echo "Please make sure the src is valid."
  echo
  usage
  exit 1
fi
if ! [[ $2 =~ ^[0-9]+$ ]]; then
  echo "Please make sure x is a number."
  echo
  usage
  exit 1
fi

showArgs $1 $2

# preprocess
shout "Preprocessing $1..."
python lda_prepare.py 1 $1

# lda
for i in `seq 1 $2`; do
  shout "Doing lda on $1 with $i topic count..."
  python lda_process.py $1_LDA t $i
  python lda_analyze.py $1_LDA t $i pp_test
done

shout "DONE!"
