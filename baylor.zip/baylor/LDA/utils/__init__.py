"""
This package contains helper classes.
"""