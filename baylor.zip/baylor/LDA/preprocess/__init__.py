"""
This package contains classes to preprocess the corpus
"""