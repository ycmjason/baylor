class Stoplist:
    def __init__(self, stopwords = []):
        self.stopwords = stopwords
    def isStopword(self, word):
        return word in self.stopwords

class MySqlStoplist(Stoplist):
    def __init__(self):
        # each line should contain a stopword
        lines = open("preprocess/stopwords_mysql.txt", "r")
        stopwords = [line.rstrip() for line in lines]
        Stoplist.__init__(self, stopwords)
